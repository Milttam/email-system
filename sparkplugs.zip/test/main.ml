open OUnit2
(* open Sparkplugs *)

let suite = "test suite for sparkplugs" >::: List.flatten []
let () = run_test_tt_main suite

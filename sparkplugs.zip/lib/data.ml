
module User = struct
  type t = {
    user : string;
    pass : string;
    priv_k : int;
    pub_k : int;
    messages : int list
  }

  let get_user (u : t) : string = u.user
  let get_pass (u : t) : string = u.pass
  let get_private (u : t) : int = u.priv_k
  let get_public (u : t) : int = u.pub_k
  let get_mes (u : t) : int list = u.messages
  let check_pass (u : t) (st : string) : bool = st = u.pass
  let compare (u1 : t) (u2 : t) : int = String.compare u1.user u2.user
end

module Message = struct
  type t = {
    time : int;
    sender : int;
    recip : int;
    mess : string;
    prev_mess : t option;
  }

  let compare (a : t) (b : t) : int = if a.time >= b.time then 1 else -1

  let get_time (m : t) : int = m.time 
  (* let day = 86400 in
  let hour = 3600 in
  let minute = 60 in m.time *)

  let get_sender (m : t) : int = m.sender
  let get_recip (m : t) : int = m.recip
  let get_mess (m : t) : string = m.mess
  let get_prev_mess (m : t) : t option = m.prev_mess
end

module Keys = struct
  type t = int

  let compare (a : t) (b : t) : int = 
    if a >= b then 1 else -1
end

module MId = struct
  let counter = ref 0
  let inc = 
    fun () -> 
      counter:= !counter +1;
      !counter
  end
  
module UId = struct
  let counter = ref 0
  let inc = 
    fun () -> 
      counter:= !counter +1;
      !counter
end
(*sqlite3 ocaml*)
module MessageMap = Map.Make (Keys)
module UserMap = Map.Make (Keys)

open Data
open User
open Message
open Map

(** Given all of the necessary parameters, creates a new message and adds the 
    message to the MessageSet*)
let sendMessage (t : int) (sen : int) (rcp : int) (txt : string)
    (prev : Message.t option) =
  let m:(Message.t) = {time = t;sender = sen; recip = rcp; mess = txt;
   prev_mess = prev} in (MessageMap.add (MId.inc ()) m MessageMap.empty) 
  (* (MessageMap.singleton sen).mess   *)
   

(** Given a message, removes it from the message set*)
let deleteMessage (k : int) = MessageMap.remove k


(** Takes the message and gives it to the user in a easily digestible form*)
let openMessage (k: int) = failwith "Unimplemented"


(** Given all of the necessary parameters, creates a new user and adds the 
    user to the UserSet*)
let createUser (username:string) (password:string) (priv:int) (pub:int) =
  let u:(User.t) = {user = username;pass = password; pub_k = pub; priv_k = priv; messages =[]}
 in UserMap.add (UId.inc ()) u UserMap.empty


(** Given a user, removes it from the user set*)
let deleteUser (k: int) = UserMap.remove k UserMap.empty


(** Given a message and a user, returns true if the message was sent or recieved
    by the user*)
(* let isUsersMessage (m: Message.t) (u: User.t): bool =
  if (m.recip == u.user) || (m.sender == u.user) then true else false *)

  
(** Given a set of messages and a user, returns the set of messages that are *)
(* let filter (m: int MessageMap.t) (u: User.t) =
  MessageMap.filter (fun (x : Message.t) (y : int) -> isUsersMessage x u ) m  *)




